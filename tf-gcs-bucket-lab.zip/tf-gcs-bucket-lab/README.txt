Simple Terraform lab: create one GCS bucket.

1. gcloud auth application-default login --no-launch-browser
2. gcloud config get-value project
3. cp terraform.tfvars.example terraform.tfvars
4. Edit project_id and bucket_name (bucket names are globally unique)
5. terraform init
6. terraform plan -var-file=terraform.tfvars
7. terraform apply -var-file=terraform.tfvars
8. gsutil ls
9. terraform destroy -var-file=terraform.tfvars
