resource "google_storage_bucket" "lab" {
  name          = var.bucket_name
  location      = var.region
  force_destroy = true

  uniform_bucket_level_access = true

  versioning {
    enabled = true
  }

  labels = {
    lab = "terraform-gcs"
  }
}

output "bucket_name" {
  value = google_storage_bucket.lab.name
}

output "bucket_url" {
  value = google_storage_bucket.lab.url
}
