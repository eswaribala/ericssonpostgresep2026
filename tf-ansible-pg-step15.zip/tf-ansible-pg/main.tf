module "network" {
  source         = "./modules/network"
  create_network = var.create_network
  network_name   = var.network_name
  subnet_name    = var.subnet_name
  subnet_cidr    = var.subnet_cidr
  region         = var.region
}

module "iam" {
  source     = "./modules/iam"
  project_id = var.project_id
}

module "compute" {
  source   = "./modules/compute"
  name     = var.vm_name
  zone     = var.zone
  subnet   = module.network.subnet_self_link
  sa_email = module.iam.vm_email
}

module "sql" {
  source     = "./modules/sql"
  name       = var.sql_name
  region     = var.region
  network_id = module.network.network_id
  password   = var.sql_password
  depends_on = [module.network]
}

output "vm_ip" {
  value = module.compute.internal_ip
}

output "sql_connection" {
  value = module.sql.connection_name
}

output "sql_private_ip" {
  value = module.sql.private_ip
}
