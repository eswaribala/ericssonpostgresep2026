Copy this folder to /home/rps/tf-ansible-pg
cp env/terraform.tfvars.example env/terraform.tfvars
edit project_id
cd /home/rps/tf-ansible-pg
terraform init
terraform fmt -recursive
# import existing 1.1-1.3 resources if they already exist, then:
terraform plan -var-file=env/terraform.tfvars
terraform apply -var-file=env/terraform.tfvars
