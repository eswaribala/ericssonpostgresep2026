variable "project_id" {
  type = string
}

resource "google_service_account" "vm" {
  account_id   = "pg-vm-sa"
  display_name = "PostgreSQL VM"
}

resource "google_service_account" "sql" {
  account_id   = "pg-sql-client-sa"
  display_name = "Cloud SQL client"
}

resource "google_project_iam_member" "vm_log" {
  project = var.project_id
  role    = "roles/logging.logWriter"
  member  = "serviceAccount:${google_service_account.vm.email}"
}

resource "google_project_iam_member" "vm_mon" {
  project = var.project_id
  role    = "roles/monitoring.metricWriter"
  member  = "serviceAccount:${google_service_account.vm.email}"
}

resource "google_project_iam_member" "sql_client" {
  project = var.project_id
  role    = "roles/cloudsql.client"
  member  = "serviceAccount:${google_service_account.sql.email}"
}

output "vm_email" {
  value = google_service_account.vm.email
}

output "sql_email" {
  value = google_service_account.sql.email
}
