variable "name" {
  type = string
}

variable "zone" {
  type = string
}

variable "subnet" {
  type = string
}

variable "sa_email" {
  type = string
}

data "google_compute_image" "ubuntu" {
  family  = "ubuntu-2404-lts-amd64"
  project = "ubuntu-os-cloud"
}

resource "google_compute_instance" "vm" {
  name         = var.name
  machine_type = "e2-medium"
  zone         = var.zone
  tags         = ["pg-lab"]

  boot_disk {
    initialize_params {
      image = data.google_compute_image.ubuntu.self_link
      size  = 20
      type  = "pd-balanced"
    }
  }

  network_interface {
    subnetwork = var.subnet
  }

  service_account {
    email  = var.sa_email
    scopes = ["cloud-platform"]
  }

  metadata = {
    enable-oslogin = "TRUE"
  }
}

output "internal_ip" {
  value = google_compute_instance.vm.network_interface[0].network_ip
}
