variable "create_network" {
  type = bool
}

variable "network_name" {
  type = string
}

variable "subnet_name" {
  type = string
}

variable "subnet_cidr" {
  type = string
}

variable "region" {
  type = string
}

data "google_compute_network" "this" {
  name = var.network_name
}

data "google_compute_subnetwork" "this" {
  name   = var.subnet_name
  region = var.region
}

resource "google_compute_global_address" "psa" {
  name          = "pg-lab-psa"
  purpose       = "VPC_PEERING"
  address_type  = "INTERNAL"
  prefix_length = 16
  network       = data.google_compute_network.this.id
}

resource "google_service_networking_connection" "psa" {
  network                 = data.google_compute_network.this.id
  service                 = "servicenetworking.googleapis.com"
  reserved_peering_ranges = [google_compute_global_address.psa.name]
}

resource "google_compute_firewall" "iap_ssh" {
  name    = "pg-lab-allow-iap-ssh"
  network = data.google_compute_network.this.name

  allow {
    protocol = "tcp"
    ports    = ["22"]
  }

  source_ranges = ["35.235.240.0/20"]
  target_tags   = ["pg-lab"]
}

resource "google_compute_firewall" "pg" {
  name    = "pg-lab-allow-5432-internal"
  network = data.google_compute_network.this.name

  allow {
    protocol = "tcp"
    ports    = ["5432"]
  }

  source_ranges = [var.subnet_cidr]
  target_tags   = ["pg-lab"]
}

output "network_id" {
  value = data.google_compute_network.this.id
}

output "subnet_self_link" {
  value = data.google_compute_subnetwork.this.self_link
}
